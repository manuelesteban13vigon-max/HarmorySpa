# DEFINICIÓN: app/api/v1/router.py - Enrutador central de la versión 1 (v1).
# Sirve para agrupar de forma organizada todos los submódulos de la API (clientes, citas, etc.) bajo un mismo punto de acceso.

from fastapi import APIRouter

api_router = APIRouter()

# En las siguientes fases registraremos aquí los routers de:
# auth, clientes, empleados, procedimientos, citas, tratamientos, etc.
