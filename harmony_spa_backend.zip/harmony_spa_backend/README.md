<!--
DEFINICIÓN: README.md - Manual e instrucciones globales del proyecto.
Sirve para documentar cómo instalar, configurar y ejecutar el backend de Harmony Spa.
-->